# NexaMind

NexaMind is a multi-agent AI assistant that dynamically discovers and coordinates specialized AI agents to solve complex tasks through intelligent Search and Discovery.

## Project Structure

- backend: FastAPI backend with agent orchestration and FAISS semantic search
- frontend: Next.js + Tailwind CSS chat UI to interact with NexaMind

## Running Locally

### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:3000 in your browser to use NexaMind.

---

## About

Built using OpenAI API, FAISS, CrewAI, LangChain, and modern web technologies.

---

## License

MIT

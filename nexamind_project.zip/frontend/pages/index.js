import { useState } from "react";

export default function Home() {
  const [query, setQuery] = useState("");
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!query) return;
    setLoading(true);

    const res = await fetch("/api/orchestrate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query }),
    });
    const data = await res.json();
    setHistory((prev) => [...prev, { query, response: data.result, agents: data.agents_used }]);
    setQuery("");
    setLoading(false);
  }

  return (
    <div className="max-w-xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">NexaMind</h1>
      <form onSubmit={handleSubmit} className="mb-4">
        <input
          type="text"
          className="border rounded p-2 w-full"
          placeholder="Ask NexaMind..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          disabled={loading}
        />
      </form>
      <div>
        {history.map(({ query, response, agents }, i) => (
          <div key={i} className="mb-4 border-b pb-2">
            <p><strong>You:</strong> {query}</p>
            <p><strong>NexaMind:</strong> {response}</p>
            <p className="text-sm text-gray-500">Agents involved: {agents.join(", ")}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

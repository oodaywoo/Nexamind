from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import asyncio
import openai
import faiss
import numpy as np

app = FastAPI()

openai.api_key = "YOUR_OPENAI_API_KEY"

agents = [
    {
        "id": "research_agent",
        "name": "ResearchAgent",
        "description": "Specialized in gathering research papers and summaries",
        "domain": "Education",
        "skills": ["literature review", "summarization", "fact checking"],
        "endpoint": "local"
    },
    {
        "id": "writing_agent",
        "name": "WritingAgent",
        "description": "Expert in drafting reports, blogs, and campaigns",
        "domain": "Content Creation",
        "skills": ["writing", "editing", "content generation"],
        "endpoint": "local"
    },
    {
        "id": "review_agent",
        "name": "ReviewAgent",
        "description": "Provides fact checking and quality assurance for generated content",
        "domain": "Quality Control",
        "skills": ["fact checking", "QA"],
        "endpoint": "local"
    }
]

agent_texts = [agent["description"] for agent in agents]
agent_embeddings = []
faiss_index = None

class Query(BaseModel):
    query: str

@app.on_event("startup")
async def build_faiss_index():
    global faiss_index, agent_embeddings
    agent_embeddings = []
    for desc in agent_texts:
        emb = await openai.Embedding.acreate(
            model="text-embedding-3-small",
            input=desc
        )
        agent_embeddings.append(emb['data'][0]['embedding'])
    d = len(agent_embeddings[0])
    faiss_index = faiss.IndexFlatL2(d)
    faiss_index.add(np.array(agent_embeddings).astype('float32'))

@app.post("/find_agents")
async def find_agents(query: Query):
    if not faiss_index:
        raise HTTPException(status_code=503, detail="FAISS index not ready")
    q_emb = np.array([await openai.Embedding.acreate(
        model="text-embedding-3-small",
        input=query.query
    )['data'][0]['embedding']]).astype('float32')
    distances, indices = faiss_index.search(q_emb, k=3)
    results = []
    for idx in indices[0]:
        results.append(agents[idx])
    return {"agents": results}

async def call_agent(agent_id: str, task: str) -> str:
    return f"[{agent_id}] Completed task: {task}"

@app.post("/orchestrate")
async def orchestrate(query: Query):
    q_emb = np.array([await openai.Embedding.acreate(
        model="text-embedding-3-small",
        input=query.query
    )['data'][0]['embedding']]).astype('float32')
    distances, indices = faiss_index.search(q_emb, k=3)
    agent_calls = []
    for idx in indices[0]:
        agent_id = agents[idx]["id"]
        agent_calls.append(call_agent(agent_id, query.query))
    results = await asyncio.gather(*agent_calls)
    combined = "\n".join(results)
    return {"result": combined, "agents_used": [agents[idx]["name"] for idx in indices[0]]}
